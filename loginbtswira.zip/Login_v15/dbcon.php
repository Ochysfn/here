<?php


	# code...

	echo "helooo bro your user name is :".$_POST["Username"];
	echo "<hr>";
	echo "and your password is : ".$_POST["password"];


 ?>